# Caso Carolina · carpeta de trabajo

Esta carpeta es todo el caso. Ábrela completa en Antigravity (File > Open Folder) y no trabajes fuera de ella.

| Carpeta | Qué va ahí | Quién escribe |
|---|---|---|
| entradas/ | Los correos de Carolina, uno por etapa. Es lo que se pide. | Nadie. Se leen. |
| datos/ | Los archivos originales que llegan con cada correo. | Nadie. Nunca se modifican. |
| contexto/ | CONTEXTO.md con quién pide, qué pregunta, las reglas y las decisiones. PLAN.md con el plan aprobado de cada etapa. | Tú y Antigravity, en cada etapa. |
| procesamiento/ | Scripts y bases intermedias que arma Antigravity. | Antigravity. |
| salidas/ | Lo que se entrega: respuestas a Carolina, el Excel del comité y la presentación. | Antigravity, revisado por el grupo. |
| archivo/ | Versiones viejas o pruebas descartadas. Nada se borra, se archiva. | El grupo. |

Cada vez que llega un correo nuevo, descomprime su ZIP sobre la misma carpeta donde está caso-carolina. Los archivos nuevos se suman a los que ya tienes.
