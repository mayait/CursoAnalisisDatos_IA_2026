# salidas

Solo lo que se entrega o se revisa: respuesta a Carolina de cada etapa (etapa-1-respuesta.md, etapa-2-respuesta.md...), el Excel del comité y la presentación.
