# archivo

Versiones viejas y pruebas descartadas. Nada se borra: se mueve aquí con la fecha en el nombre.
