# procesamiento

Scripts y bases intermedias. Antigravity escribe aquí. Si un script se reemplaza, la versión vieja va a archivo/.
