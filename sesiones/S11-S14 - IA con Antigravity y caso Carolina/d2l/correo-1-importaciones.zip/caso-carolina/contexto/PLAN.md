# Plan de trabajo

Antigravity escribe aquí el plan de cada etapa antes de ejecutar. El grupo lo aprueba o lo corrige.
