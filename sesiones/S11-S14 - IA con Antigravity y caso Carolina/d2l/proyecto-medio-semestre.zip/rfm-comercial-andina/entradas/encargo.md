**De:** Andrés Villacís, Gerente Comercial de Comercial Andina
**Para:** Equipo de análisis
**Fecha:** miércoles 7 de octubre de 2026
**Asunto:** ¿Quiénes son nuestros clientes y qué le decimos a cada uno?
**Adjuntos:** datos/ventas.csv, datos/clientes.csv, datos/productos.csv, datos/sucursales.csv

Equipo:

Para el plan comercial de 2026 quiero dejar de tratar a todos los clientes igual. Tenemos 1.800 clientes en cinco ciudades y la mitad del presupuesto de promociones se va en descuentos para gente que igual iba a comprar.

Les paso las ventas de 2024 y 2025 de todas las sucursales, la ficha de clientes, los productos con su costo y las sucursales. Sistemas me advierte que las ventas vienen con devoluciones, algunas ventas sin cliente identificado, fechas en más de un formato y precios vacíos.

Necesito tres cosas:

1. Para cada cliente, cuándo compró por última vez, cuántas veces compra, cuánto nos compra y cuánto margen nos deja.
2. Pocos segmentos, con un nombre que mi equipo entienda, y cuántos clientes y cuánto margen hay en cada uno.
3. Qué le decimos a cada segmento el próximo mes, cuánto nos costaría y qué esperamos ganar.

Quiero un Excel con una fila por cliente y su segmento, una presentación de ocho a diez láminas para mi comité y que me expliquen qué dejaron fuera de los datos y por qué. La fecha de corte es el 31 de diciembre de 2025.

Gracias,
Andrés
