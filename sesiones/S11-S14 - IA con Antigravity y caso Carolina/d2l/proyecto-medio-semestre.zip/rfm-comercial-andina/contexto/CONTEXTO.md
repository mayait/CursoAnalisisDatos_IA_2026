# Contexto del proyecto

Antigravity: lee este archivo antes de cualquier tarea y actualízalo al cerrar cada etapa.

## Quién pide y para qué
- Pide: Andrés Villacís, Gerente Comercial de Comercial Andina.
- Pregunta: quiénes son nuestros clientes, cuánto valen y qué le decimos a cada segmento el próximo mes.
- Fecha de corte: 31 de diciembre de 2025.

## Definiciones (completar y justificar)
- Recencia: días entre la última compra del cliente y la fecha de corte.
- Frecuencia: número de facturas distintas del cliente.
- Monto: ventas netas del cliente, restando devoluciones.
- Margen (P): ventas netas menos costo (cantidad por costo unitario de productos.csv).

## Reglas de trabajo
- Los archivos de datos/ no se modifican nunca.
- Todo lo intermedio va a procesamiento/; todo lo que se entrega va a salidas/.
- Antes de ejecutar, plan y visto bueno del grupo.
- Cada cifra dice de qué archivo sale.

## Decisiones tomadas
(Devoluciones, ventas sin cliente, fechas, precios vacíos: qué se hizo y por qué.)

## Etapas cerradas
(Etapa, salida en salidas/ y cifras de control.)
