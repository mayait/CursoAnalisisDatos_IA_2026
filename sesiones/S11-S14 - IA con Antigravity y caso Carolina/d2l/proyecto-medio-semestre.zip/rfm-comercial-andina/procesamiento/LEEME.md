# procesamiento

Scripts y bases intermedias. Antigravity escribe aquí.
