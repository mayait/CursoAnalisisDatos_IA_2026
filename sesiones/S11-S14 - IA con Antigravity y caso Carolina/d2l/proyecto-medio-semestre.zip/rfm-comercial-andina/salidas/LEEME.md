# salidas

Entregables: rfm-por-cliente.xlsx, presentacion-comite (PDF o PPTX), bitacora-ia.md.
